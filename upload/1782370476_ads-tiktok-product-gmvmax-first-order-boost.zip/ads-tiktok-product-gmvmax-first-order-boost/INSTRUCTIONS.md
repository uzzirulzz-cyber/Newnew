# Instructions

Use this skill only after the agent platform has connected to TikTok Remote MCP with OAuth.

## Install

```bash
cd <SKILL_DIR>
npm install
npm run check
```

## Use with an OAuth-connected agent

Ask the agent to read this skill package and execute the flow with TikTok MCP tools.

Example instruction:

```text
Use the skill ads-tiktok-product-gmvmax-first-order-boost.
TikTok Remote MCP is already connected through OAuth.
Run DRY_RUN first for advertiser <ADVERTISER_ID>, campaign <CAMPAIGN_ID>, date <QUERY_DATE>.
Do not create any boost session until I explicitly approve LIVE.
```

## DRY_RUN

Use a PowerShell variable so JSON is passed to Node unchanged:

```powershell
$inputJson = '{"advertiser_id":"<ADVERTISER_ID>","campaign_id":"<CAMPAIGN_ID>","date":"<QUERY_DATE>","mode":"DRY_RUN"}'
node src/index.js find_first_order_creatives $inputJson
```

If `campaign_id` is unknown, remove the field instead of passing an empty string.

## LIVE

Generate the LIVE plan immediately before creating sessions. The generated `schedule_end_time` uses the current UTC date at `23:59:59`.

```powershell
$inputJson = '{"advertiser_id":"<ADVERTISER_ID>","campaign_id":"<CAMPAIGN_ID>","date":"<QUERY_DATE>","mode":"LIVE","allow_live":true,"max_boosts_per_run":3}'
node src/index.js execute_first_order_boost $inputJson
```

The command returns a structured tool-call plan. The agent must execute the listed TikTok MCP tools through the OAuth-connected MCP connector.

## Do not configure

Do not configure these in this package:

```text
TIKTOK_MCP_ACCESS_TOKEN
TIKTOK_ACCESS_TOKEN
TIKTOK_MCP_AUTHORIZATION
```

OAuth belongs to the MCP host, not the skill package.
