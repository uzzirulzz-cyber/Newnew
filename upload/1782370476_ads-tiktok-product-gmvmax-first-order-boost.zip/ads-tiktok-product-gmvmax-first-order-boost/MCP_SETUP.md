# TikTok Remote MCP Setup

This skill uses Remote TikTok MCP with OAuth.

## Recommended URL

```text
https://business-api.tiktok.com/open_mcp/tt-ads-mcp-flat
```

Use this when the platform supports large or deferred tool loading.

## Alternate layered URL

```text
https://business-api.tiktok.com/open_mcp/tt-ads-mcp-layer-v2
```

Use this when the platform has a limited context window or prefers layered tool discovery.

## Claude-style setup

1. Open the agent platform settings.
2. Add a custom connector or Remote MCP server.
3. Enter the MCP URL.
4. Choose OAuth authentication.
5. Authorize with TikTok for Business.
6. Enable the connector in the working chat.

## ChatGPT-style setup

1. Open app or connector settings.
2. Enable developer or advanced app setup if required.
3. Create a custom app or Remote MCP connection.
4. Enter the MCP URL.
5. Select OAuth authentication.
6. Authorize with TikTok for Business.
7. Enable the MCP server in the chat.

## Codex or Claude Code

Use this skill only if your coding agent session can access the TikTok Remote MCP connector.

If the coding agent cannot access OAuth-based Remote MCP tools directly, use a host platform that can, or add an MCP bridge outside this package. Do not put TikTok access tokens into this skill package.
