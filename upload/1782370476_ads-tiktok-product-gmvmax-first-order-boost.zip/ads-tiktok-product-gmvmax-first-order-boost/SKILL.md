---
name: ads-tiktok-product-gmvmax-first-order-boost
version: 1.0.10
description: "Use when planning or executing TikTok Product GMV Max first-order Creative Boost workflows through OAuth-connected TikTok Remote MCP."
user-invocable: true
disable-model-invocation: true
---

# TikTok Product GMV Max First-Order Creative Boost

## Purpose

Find Product GMV Max videos that receive their first order on a selected reporting date and create a one-day Creative Boost session for eligible videos.

## Required MCP setup

The host agent must connect to TikTok Remote MCP with OAuth before using this skill.

Recommended MCP URL:

```text
https://business-api.tiktok.com/open_mcp/tt-ads-mcp-flat
```

Use OAuth in the agent platform. Do not pass TikTok access tokens to the skill.

## Required inputs

```json
{
  "advertiser_id": "<ADVERTISER_ID>",
  "campaign_id": "<CAMPAIGN_ID>",
  "date": "<QUERY_DATE>",
  "mode": "DRY_RUN"
}
```

`campaign_id` is optional. If omitted, discover active Product GMV Max campaigns first.

## First-order definition

A video is first-order only when:

```text
orders on <QUERY_DATE> >= min_orders
and
orders during the previous first_order_lookback_days reporting dates = 0
```

Default lookback is 7 days. Reporting dates use the ad account timezone.

## Candidate source rule

Always start with `gmv_max_video_get` eligible video pool.

Do not start from report rows and then reverse-search videos. A report row can show orders but still fail Creative Boost because it may not map to a boostable TikTok item identity.

## DRY_RUN tool sequence

1. `gmv_max_campaign_get` when `campaign_id` is omitted.
2. `campaign_gmv_max_info_get` for each selected campaign.
3. `gmv_max_identity_get` to build `identity_list` for video lookup.
4. `gmv_max_video_get` to fetch eligible videos.
5. `gmv_max_report_get` for the previous lookback window, with pagination.
6. `gmv_max_report_get` for the query date, with pagination.
7. Intersect eligible videos with report rows.
8. Return candidates only. Do not create sessions.

## LIVE tool sequence

Use the DRY_RUN sequence first, then:

1. `campaign_gmv_max_session_list_get` to check conflicts.
2. `campaign_gmv_max_session_create` to create a Creative Boost session.
3. `campaign_gmv_max_session_get` to verify readback.

## Create payload shape

```json
{
  "advertiser_id": "<ADVERTISER_ID>",
  "campaign_id": "<CAMPAIGN_ID>",
  "store_id": "<STORE_ID>",
  "session": {
    "bid_type": "CREATIVE_NO_BID",
    "item_id": "<BOOST_ITEM_ID_FROM_GMV_MAX_VIDEO_GET>",
    "product_list": [
      { "spu_id": "<ITEM_GROUP_ID>" }
    ],
    "budget": "<CALCULATED_BOOST_BUDGET>",
    "schedule_type": "SCHEDULE_START_END",
    "schedule_end_time": "<CURRENT_UTC_DATE_23_59_59>"
  }
}
```

Do not pass identity fields in `session_create`.

## Safety

- Default to DRY_RUN.
- LIVE requires explicit user instruction.
- LIVE requires `allow_live: true`.
- Generate LIVE plans immediately before creating sessions; `schedule_end_time` uses the current UTC date at `23:59:59`.
- Do not create more than `max_boosts_per_run` sessions.
- Skip videos with existing active Creative Boost sessions.
- Skip products with active Max Delivery sessions.
- Verify created sessions with readback.
