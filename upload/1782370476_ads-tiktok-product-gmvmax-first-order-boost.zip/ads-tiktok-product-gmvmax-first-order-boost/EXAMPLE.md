# Examples

## DRY_RUN prompt for Codex or Claude Code

```text
Use the local skill package ads-tiktok-product-gmvmax-first-order-boost.
TikTok Remote MCP is already connected through OAuth.
Run a DRY_RUN for:
- advertiser_id: <ADVERTISER_ID>
- campaign_id: <CAMPAIGN_ID>
- date: <QUERY_DATE>

Follow the skill flow exactly:
1. Load GMV Max campaign context.
2. Fetch Product GMV Max identities.
3. Fetch gmv_max_video_get eligible video pool.
4. Query paginated reports for the query date and previous lookback window.
5. Return first-order candidates only.
Do not call campaign_gmv_max_session_create.
```

## LIVE prompt

```text
Use the same skill package and execute LIVE for the approved candidates.
TikTok Remote MCP is already connected through OAuth.
Use:
- advertiser_id: <ADVERTISER_ID>
- campaign_id: <CAMPAIGN_ID>
- date: <QUERY_DATE>
- max_boosts_per_run: <MAX_BOOSTS>
- boost_budget_ratio: <BOOST_BUDGET_RATIO>

Before creating a session, check active sessions.
Generate the LIVE plan immediately before creation; `schedule_end_time` uses the current UTC date at `23:59:59`.
After creating a session, verify it with campaign_gmv_max_session_get.
Return session_id and readback result.
```
