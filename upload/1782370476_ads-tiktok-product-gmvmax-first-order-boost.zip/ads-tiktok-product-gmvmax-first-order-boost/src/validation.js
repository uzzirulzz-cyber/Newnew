import { z } from "zod";

const yyyyMmDd = /^\d{4}-\d{2}-\d{2}$/;

const BaseInputSchema = z.object({
  advertiser_id: z.string().min(1),
  campaign_id: z.string().min(1).optional(),
  date: z.string().regex(yyyyMmDd, "date must be YYYY-MM-DD"),
  mode: z.enum(["DRY_RUN", "LIVE"]).default("DRY_RUN"),
  min_orders: z.number().int().positive().default(1),
  first_order_lookback_days: z.number().int().min(1).max(30).default(7),
  boost_budget_ratio: z.number().positive().max(1).default(0.2),
  max_boost_budget_ratio: z.number().positive().max(1).default(0.2),
  boost_budget_fixed: z.number().positive().optional(),
  max_boosts_per_run: z.number().int().min(1).max(100).default(20),
  report_page_size: z.number().int().min(1).max(1000).default(1000),
  max_report_pages: z.number().int().min(1).max(100).default(20),
  video_page_size: z.number().int().min(1).max(50).default(50),
  max_video_pages: z.number().int().min(1).max(100).default(20),
  reporting_timezone: z.literal("AD_ACCOUNT_TIMEZONE").default("AD_ACCOUNT_TIMEZONE"),
  schedule_timezone: z.literal("UTC").default("UTC"),
  include_skipped: z.boolean().default(false),
  include_diagnostics: z.boolean().default(true)
});

export const FindFirstOrderCreativesInputSchema = BaseInputSchema.extend({
  mode: z.literal("DRY_RUN").default("DRY_RUN")
});

export const ExecuteFirstOrderBoostInputSchema = BaseInputSchema.extend({
  mode: z.literal("LIVE"),
  allow_live: z.literal(true)
});

export function parseToolInput(name, input) {
  if (name === "find_first_order_creatives") return FindFirstOrderCreativesInputSchema.parse(input || {});
  if (name === "execute_first_order_boost") return ExecuteFirstOrderBoostInputSchema.parse(input || {});
  throw new Error(`Unknown tool: ${name}`);
}

export function zodErrorToResponse(error) {
  return {
    error: "FAILED_VALIDATION",
    message: "Input validation failed.",
    issues: error.issues.map((issue) => ({
      path: issue.path.join("."),
      message: issue.message
    }))
  };
}
