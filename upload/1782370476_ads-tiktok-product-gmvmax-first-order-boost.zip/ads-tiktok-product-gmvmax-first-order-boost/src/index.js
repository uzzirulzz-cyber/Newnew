import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  find_first_order_creatives,
  execute_first_order_boost,
  formatToolError
} from "./server.js";

export { find_first_order_creatives, execute_first_order_boost } from "./server.js";

const tools = {
  find_first_order_creatives,
  execute_first_order_boost
};

function samePath(left, right) {
  const normalizedLeft = path.normalize(left);
  const normalizedRight = path.normalize(right);
  if (process.platform === "win32") {
    return normalizedLeft.toLowerCase() === normalizedRight.toLowerCase();
  }
  return normalizedLeft === normalizedRight;
}

function isCliEntrypoint() {
  if (!process.argv[1]) return false;
  return samePath(fileURLToPath(import.meta.url), path.resolve(process.argv[1]));
}

if (isCliEntrypoint()) {
  const [, , toolName, rawInput] = process.argv;

  if (!toolName) {
    console.log(JSON.stringify({ tools: Object.keys(tools) }, null, 2));
    process.exit(0);
  }

  let input = {};
  try {
    input = rawInput ? JSON.parse(rawInput) : {};
  } catch {
    console.error(JSON.stringify({ error: "FAILED_VALIDATION", message: "Input must be valid JSON." }, null, 2));
    process.exit(1);
  }

  try {
    const tool = tools[toolName];
    if (!tool) throw new Error(`Unknown tool: ${toolName}`);

    const result = await tool(input);
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error(JSON.stringify(formatToolError(error), null, 2));
    process.exit(1);
  }
}
