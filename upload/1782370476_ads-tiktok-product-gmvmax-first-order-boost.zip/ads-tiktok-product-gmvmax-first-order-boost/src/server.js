import { ZodError } from "zod";
import { parseToolInput, zodErrorToResponse } from "./validation.js";
import { buildFindPlan, buildExecutePlan } from "./plan.js";

export async function find_first_order_creatives(input) {
  const parsed = parseToolInput("find_first_order_creatives", input || {});
  return buildFindPlan(parsed);
}

export async function execute_first_order_boost(input) {
  const parsed = parseToolInput("execute_first_order_boost", input || {});
  return buildExecutePlan(parsed);
}

export function formatToolError(error) {
  if (error instanceof ZodError) return zodErrorToResponse(error);
  return {
    error: error.code || "TOOL_EXECUTION_ERROR",
    message: error.message,
    details: error.details || null
  };
}
