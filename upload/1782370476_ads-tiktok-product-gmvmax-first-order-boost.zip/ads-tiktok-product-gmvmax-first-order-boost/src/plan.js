const FLAT_MCP_URL = "https://business-api.tiktok.com/open_mcp/tt-ads-mcp-flat";
const LAYER_MCP_URL = "https://business-api.tiktok.com/open_mcp/tt-ads-mcp-layer-v2";

function addDays(dateStr, days) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function currentUtcDayEnd(now = new Date()) {
  return `${now.toISOString().slice(0, 10)} 23:59:59`;
}

function previousRange(dateStr, lookbackDays) {
  return {
    start_date: addDays(dateStr, -lookbackDays),
    end_date: addDays(dateStr, -1),
    lookback_days: lookbackDays
  };
}

function tool(name, purpose, args, notes = []) {
  return { tool_name: name, purpose, arguments: args, notes };
}

function commonSetup(input) {
  const prev = previousRange(input.date, input.first_order_lookback_days);
  return {
    mcp_connection: {
      required: true,
      mode: "Remote MCP with OAuth in the agent platform",
      recommended_url: FLAT_MCP_URL,
      alternate_url: LAYER_MCP_URL,
      do_not_use_access_token_env: true
    },
    input_summary: {
      advertiser_id: input.advertiser_id,
      campaign_id: input.campaign_id || "<ALL_ACTIVE_PRODUCT_GMV_MAX_CAMPAIGNS>",
      date: input.date,
      reporting_timezone: input.reporting_timezone,
      schedule_timezone: input.schedule_timezone,
      first_order_lookback_days: input.first_order_lookback_days,
      previous_range: prev,
      min_orders: input.min_orders,
      boost_budget_ratio: input.boost_budget_ratio,
      max_boost_budget_ratio: input.max_boost_budget_ratio,
      boost_budget_fixed: input.boost_budget_fixed ?? null
    }
  };
}

function campaignDiscoveryStep(input) {
  if (input.campaign_id) {
    return tool(
      "campaign_gmv_max_info_get",
      "Load the selected GMV Max campaign and confirm Product GMV Max context.",
      {
        advertiser_id: input.advertiser_id,
        campaign_id: input.campaign_id
      },
      [
        "Confirm shopping_ads_type is PRODUCT.",
        "Read store_id, store_authorized_bc_id, campaign budget, item_group_ids, identity_list, product_video_specific_type."
      ]
    );
  }

  return tool(
    "gmv_max_campaign_get",
    "List active Product GMV Max campaigns for the advertiser.",
    {
      advertiser_id: input.advertiser_id,
      filtering: {
        gmv_max_promotion_types: ["PRODUCT_GMV_MAX"],
        primary_status: "STATUS_DELIVERY_OK"
      },
      page: 1,
      page_size: 100
    },
    [
      "For each returned campaign, call campaign_gmv_max_info_get before reading store/product context.",
      "If pagination is returned, continue until all active Product GMV Max campaigns are loaded."
    ]
  );
}

function findSteps(input) {
  const prev = previousRange(input.date, input.first_order_lookback_days);
  return [
    campaignDiscoveryStep(input),
    tool(
      "campaign_gmv_max_info_get",
      "For every selected campaign, load GMV Max campaign details.",
      {
        advertiser_id: input.advertiser_id,
        campaign_id: "<CAMPAIGN_ID_FROM_DISCOVERY_OR_INPUT>"
      },
      [
        "Use store_id and store_authorized_bc_id from this response.",
        "Use campaign budget for budget calculation.",
        "Use item_group_ids when present; otherwise infer product IDs from report rows."
      ]
    ),
    tool(
      "gmv_max_identity_get",
      "Get identities available for Product GMV Max video lookup.",
      {
        advertiser_id: input.advertiser_id,
        store_id: "<STORE_ID_FROM_CAMPAIGN_INFO>",
        store_authorized_bc_id: "<STORE_AUTHORIZED_BC_ID_FROM_CAMPAIGN_INFO>"
      },
      [
        "Build identity_list for gmv_max_video_get.",
        "If availability flags are present, prefer product_gmv_max_available identities.",
        "Fallback to campaign_gmv_max_info_get.identity_list if identity_get omits valid identities."
      ]
    ),
    tool(
      "gmv_max_video_get",
      "Fetch the eligible Product GMV Max video pool first. This is the source of boostable videos.",
      {
        advertiser_id: input.advertiser_id,
        store_id: "<STORE_ID_FROM_CAMPAIGN_INFO>",
        store_authorized_bc_id: "<STORE_AUTHORIZED_BC_ID_FROM_CAMPAIGN_INFO>",
        spu_id_list: ["<ITEM_GROUP_ID>"],
        identity_list: "<NORMALIZED_IDENTITY_LIST>",
        need_auth_code_video: true,
        page: 1,
        page_size: input.video_page_size,
        sort_field: "GMV",
        sort_type: "DESC"
      },
      [
        "Do not use keyword as the first lookup path.",
        "Paginate until fewer than page_size rows are returned or max_video_pages is reached.",
        "Normalize item_id as boost_item_id and keep video_id separately when returned."
      ]
    ),
    tool(
      "gmv_max_report_get",
      "Query previous reporting window to calculate previous orders for eligible videos.",
      {
        advertiser_id: input.advertiser_id,
        store_ids: ["<STORE_ID_FROM_CAMPAIGN_INFO>"],
        dimensions: ["campaign_id", "item_group_id", "item_id"],
        metrics: ["orders", "cost", "gross_revenue", "roi", "creative_delivery_status"],
        start_date: prev.start_date,
        end_date: prev.end_date,
        filtering: {
          campaign_ids: ["<CAMPAIGN_ID>"],
          item_group_ids: ["<ITEM_GROUP_ID>"]
        },
        page: 1,
        page_size: input.report_page_size,
        sort_field: "orders",
        sort_type: "DESC"
      },
      [
        "Paginate until all report rows are loaded or max_report_pages is reached.",
        "Group by item_group_id + item_id."
      ]
    ),
    tool(
      "gmv_max_report_get",
      "Query input date report rows and intersect with eligible video pool.",
      {
        advertiser_id: input.advertiser_id,
        store_ids: ["<STORE_ID_FROM_CAMPAIGN_INFO>"],
        dimensions: ["campaign_id", "item_group_id", "item_id"],
        metrics: ["orders", "cost", "gross_revenue", "roi", "creative_delivery_status"],
        start_date: input.date,
        end_date: input.date,
        filtering: {
          campaign_ids: ["<CAMPAIGN_ID>"],
          item_group_ids: ["<ITEM_GROUP_ID>"]
        },
        page: 1,
        page_size: input.report_page_size,
        sort_field: "orders",
        sort_type: "DESC"
      },
      [
        "Only keep rows where current orders >= min_orders and previous orders = 0.",
        "Only keep rows whose item_id exists in the gmv_max_video_get eligible video pool.",
        "Calculate boost budget using boost_budget_fixed or campaign_budget * boost_budget_ratio, capped by max_boost_budget_ratio."
      ]
    )
  ];
}

function executeSteps(input, scheduleEndTimeUtc) {
  return [
    ...findSteps(input),
    tool(
      "campaign_gmv_max_session_list_get",
      "Check active max delivery and creative boost sessions before creating a new boost.",
      {
        advertiser_id: input.advertiser_id,
        campaign_id: "<CAMPAIGN_ID>"
      },
      [
        "Skip if a CREATIVE_NO_BID session already exists for the same item_id.",
        "Skip if an active NO_BID max delivery session exists for the same product.",
        "Skip if the campaign already has 100 creative boost videos."
      ]
    ),
    tool(
      "campaign_gmv_max_session_create",
      "Create the Creative Boost session for one eligible first-order video.",
      {
        advertiser_id: input.advertiser_id,
        campaign_id: "<CAMPAIGN_ID>",
        store_id: "<STORE_ID_FROM_CAMPAIGN_INFO>",
        session: {
          bid_type: "CREATIVE_NO_BID",
          item_id: "<BOOST_ITEM_ID_FROM_GMV_MAX_VIDEO_GET>",
          product_list: [{ spu_id: "<ITEM_GROUP_ID>" }],
          budget: "<CALCULATED_BOOST_BUDGET>",
          schedule_type: "SCHEDULE_START_END",
          schedule_end_time: scheduleEndTimeUtc
        }
      },
      [
        "Do not pass identity fields in session_create; use the boost_item_id from the eligible video pool.",
        "Generate the LIVE plan immediately before creating sessions; schedule_end_time is the current UTC date at 23:59:59.",
        "Create at most max_boosts_per_run sessions.",
        "LIVE execution requires explicit user approval and allow_live=true."
      ]
    ),
    tool(
      "campaign_gmv_max_session_get",
      "Read back created sessions and verify that TikTok returned a matching CREATIVE_NO_BID session.",
      {
        advertiser_id: input.advertiser_id,
        session_ids: ["<SESSION_ID_FROM_CREATE_RESPONSE>"]
      },
      [
        "Verify item_id, bid_type and product_list.spu_id match the requested boost.",
        "Return readback result in the final report."
      ]
    )
  ];
}

export function buildFindPlan(input) {
  return {
    skill: "ads-tiktok-product-gmvmax-first-order-boost",
    version: "1.0.10",
    operation: "find_first_order_creatives",
    execution_type: "agent_remote_mcp_tool_plan",
    ...commonSetup(input),
    safety: {
      live_mutation: false,
      note: "This operation is read-only and must not call campaign_gmv_max_session_create."
    },
    tool_call_sequence: findSteps(input),
    output_contract: {
      candidates: "List eligible videos that appear in gmv_max_video_get pool and meet first-order report criteria.",
      skipped_count: "Count skipped candidates without displaying skipped rows unless include_skipped=true.",
      diagnostics: "Include MCP call pagination and identity/video pool summaries when include_diagnostics=true."
    }
  };
}

export function buildExecutePlan(input) {
  const scheduleEndTimeUtc = currentUtcDayEnd();
  return {
    skill: "ads-tiktok-product-gmvmax-first-order-boost",
    version: "1.0.10",
    operation: "execute_first_order_boost",
    execution_type: "agent_remote_mcp_tool_plan",
    ...commonSetup(input),
    safety: {
      live_mutation: true,
      required_user_confirmation: true,
      allow_live_required: true,
      max_boosts_per_run: input.max_boosts_per_run,
      schedule_end_time_utc: scheduleEndTimeUtc,
      note: "Only call campaign_gmv_max_session_create after the user explicitly requests LIVE execution. Generate the LIVE plan immediately before creation so schedule_end_time uses the current UTC day."
    },
    tool_call_sequence: executeSteps(input, scheduleEndTimeUtc),
    output_contract: {
      boosts_created: "Created sessions with session_id and readback verification.",
      failed: "Rows where create or readback failed, with TikTok error message summarized.",
      skipped_count: "Dry-run skipped count plus session-conflict skipped count.",
      diagnostics: "Include identity, video pool, report pagination, session list and readback details when requested."
    }
  };
}
