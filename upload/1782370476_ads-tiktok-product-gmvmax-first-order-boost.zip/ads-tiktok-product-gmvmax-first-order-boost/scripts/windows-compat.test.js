import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import test from "node:test";

const execFileAsync = promisify(execFile);
const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const entrypointUrl = new URL("../src/index.js", import.meta.url);

test("SKILL.md uses Claude Code invocation fields", () => {
  const skillText = fs.readFileSync(path.join(packageRoot, "SKILL.md"), "utf8");

  assert.match(skillText, /^user-invocable:\s+true$/m);
  assert.match(skillText, /^disable-model-invocation:\s+true$/m);
  assert.doesNotMatch(skillText, /^user-invokable:/m);
});

test("skill.json mirrors external invocation metadata", () => {
  const skillJson = JSON.parse(fs.readFileSync(path.join(packageRoot, "skill.json"), "utf8"));
  const legacyInvocationKey = ["user", "invokable"].join("_");

  assert.equal(skillJson.user_invocable, true);
  assert.equal(skillJson.disable_model_invocation, true);
  assert.equal(legacyInvocationKey in skillJson, false);
});

test("module API exposes tool-named functions only", async () => {
  const moduleApi = await import(entrypointUrl);
  const legacyListName = ["list", "Tools"].join("");
  const legacyRunName = ["run", "Tool"].join("");

  assert.equal(typeof moduleApi.find_first_order_creatives, "function");
  assert.equal(typeof moduleApi.execute_first_order_boost, "function");
  assert.equal(legacyListName in moduleApi, false);
  assert.equal(legacyRunName in moduleApi, false);
});

test("LIVE plan ends on the current UTC day at 23:59:59", async () => {
  const moduleApi = await import(entrypointUrl);
  const expectedEndTime = `${new Date().toISOString().slice(0, 10)} 23:59:59`;
  const plan = await moduleApi.execute_first_order_boost({
    advertiser_id: "ADVERTISER_ID",
    campaign_id: "CAMPAIGN_ID",
    date: "2020-01-01",
    mode: "LIVE",
    allow_live: true
  });
  const createStep = plan.tool_call_sequence.find(
    (step) => step.tool_name === "campaign_gmv_max_session_create"
  );

  assert.equal(createStep.arguments.session.schedule_end_time, expectedEndTime);
  assert.equal(plan.safety.schedule_end_time_utc, expectedEndTime);
});

test("CLI entrypoint lists tools when invoked by relative path", async () => {
  const { stdout } = await execFileAsync(process.execPath, ["src/index.js"], {
    cwd: packageRoot
  });

  assert.deepEqual(JSON.parse(stdout), {
    tools: ["find_first_order_creatives", "execute_first_order_boost"]
  });
});

test("CLI entrypoint runs a tool with valid JSON input", async () => {
  const { stdout } = await execFileAsync(
    process.execPath,
    [
      "src/index.js",
      "find_first_order_creatives",
      JSON.stringify({
        advertiser_id: "ADVERTISER_ID",
        date: "2026-06-16",
        mode: "DRY_RUN"
      })
    ],
    { cwd: packageRoot }
  );
  const plan = JSON.parse(stdout);

  assert.equal(plan.operation, "find_first_order_creatives");
  assert.equal(plan.execution_type, "agent_remote_mcp_tool_plan");
  assert.equal(plan.tool_call_sequence[0].tool_name, "gmv_max_campaign_get");
});

test("package validator resolves package root on Windows paths", async () => {
  const { stdout } = await execFileAsync(process.execPath, ["scripts/validate-package.js"], {
    cwd: packageRoot
  });

  assert.match(stdout, /Package validation passed\./);
});

test("INSTRUCTIONS.md uses Windows-safe JSON examples", () => {
  const instructions = fs.readFileSync(path.join(packageRoot, "INSTRUCTIONS.md"), "utf8");

  assert.match(instructions, /\$inputJson = '\{"advertiser_id":/);
  assert.doesNotMatch(instructions, /node src\/index\.js find_first_order_creatives '\{/);
  assert.doesNotMatch(instructions, /node src\/index\.js execute_first_order_boost '\{/);
});
