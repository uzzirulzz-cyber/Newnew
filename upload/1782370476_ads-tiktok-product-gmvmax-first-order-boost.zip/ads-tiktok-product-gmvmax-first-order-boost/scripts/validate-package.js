import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const required = [
  "package.json",
  "skill.json",
  "README.md",
  "SKILL.md",
  "INSTRUCTIONS.md",
  "EXAMPLE.md",
  "MCP_SETUP.md",
  "schema/tools_schema.json"
];

for (const file of required) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) throw new Error(`Missing required file: ${file}`);
}

for (const file of ["package.json", "skill.json", "schema/tools_schema.json"]) {
  JSON.parse(fs.readFileSync(path.join(root, file), "utf8"));
}

const forbidden = [
  /TIKTOK_MCP_ACCESS_TOKEN=<ACCESS_TOKEN>/,
  /TIKTOK_ACCESS_TOKEN=<ACCESS_TOKEN>/,
  /C:\\\\Users\\\\/,
  /\/mnt\/data\//
];

const forbiddenSensitiveValues = [
  ["733884", "362728", "1645570"].join(""),
  ["186233", "246565", "3809"].join(""),
  ["749550", "470839", "4388235"].join(""),
  ["172950", "706000", "7932683"].join("")
];

forbidden.push(...forbiddenSensitiveValues.map((value) => new RegExp(value)));

for (const file of required.concat([".env.example", "src/plan.js", "src/validation.js", "src/server.js", "src/index.js"])) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) continue;
  const text = fs.readFileSync(full, "utf8");
  for (const pattern of forbidden) {
    if (pattern.test(text)) throw new Error(`Forbidden real path/id/token pattern found in ${file}: ${pattern}`);
  }
}

console.log("Package validation passed.");
