# ads-tiktok-product-gmvmax-first-order-boost

Version: **1.0.10**

This package is an agent skill for TikTok **Product GMV Max** first-order Creative Boost workflows.

It does **not** call TikTok APIs directly. It returns a structured TikTok Remote MCP tool-call plan that an OAuth-connected agent platform must execute.

## What This Package Does

Use this package to generate plans for:

- `find_first_order_creatives`: build a read-only DRY_RUN plan to find first-order Product GMV Max video candidates.
- `execute_first_order_boost`: build a LIVE plan for creating one-day Creative Boost sessions and verifying them by readback.

The package keeps the boostability rule strict: a video can only be boosted when it comes from the `gmv_max_video_get` eligible video pool and also meets the first-order report rule.

## What This Package Does Not Do

- It does not perform OAuth.
- It does not accept TikTok access tokens.
- It does not call TikTok MCP tools by itself.
- It does not create boost sessions by itself.
- It does not modify campaign budget or ROI target.

## Required Platform Setup

Before using the returned plan, connect TikTok Remote MCP in the agent platform.

Recommended MCP URL:

```text
https://business-api.tiktok.com/open_mcp/tt-ads-mcp-flat
```

Alternate URL for platforms that need layered discovery:

```text
https://business-api.tiktok.com/open_mcp/tt-ads-mcp-layer-v2
```

Use OAuth authentication in the host platform and authorize with a TikTok for Business account that has access to the target advertiser.

Do not put TikTok tokens in this package or in environment variables for this package.

## Install

```powershell
cd C:\path\to\ads-tiktok-product-gmvmax-first-order-boost
npm install
```

Requirements:

- Node.js 18 or newer.
- An OAuth-connected TikTok Remote MCP host if you want to execute the returned plan.

## Supported Inputs

### `find_first_order_creatives`

Required:

- `advertiser_id`: TikTok advertiser ID.
- `date`: reporting date in `YYYY-MM-DD`.

Optional:

- `campaign_id`: Product GMV Max campaign ID. Omit this field if you want the plan to discover active Product GMV Max campaigns.
- `mode`: must be `DRY_RUN` when provided.
- `min_orders`: default `1`.
- `first_order_lookback_days`: default `7`.
- `boost_budget_ratio`: default `0.2`.
- `max_boost_budget_ratio`: default `0.2`.
- `boost_budget_fixed`: optional fixed budget; the executing agent must still enforce the max budget ratio.
- `report_page_size`: default `1000`.
- `max_report_pages`: default `20`.
- `video_page_size`: default `50`.
- `max_video_pages`: default `20`.
- `include_skipped`: default `false`.
- `include_diagnostics`: default `true`.

### `execute_first_order_boost`

Required:

- `advertiser_id`: TikTok advertiser ID.
- `date`: reporting date in `YYYY-MM-DD`.
- `mode`: must be `LIVE`.
- `allow_live`: must be `true`.

Optional:

- `campaign_id`
- `max_boosts_per_run`: default `20`.
- The same report, video, order, and budget options as `find_first_order_creatives`.

## Cross-Platform Local Calls

The recommended local interface is the exported module API. These examples work in Windows PowerShell and in Unix-like shells.

List available tool names:

```powershell
node src/index.js
```

Generate a DRY_RUN plan for all active Product GMV Max campaigns:

```powershell
node --input-type=module -e "import { find_first_order_creatives } from './src/index.js'; const plan = await find_first_order_creatives({ advertiser_id: 'ADVERTISER_ID', date: '2026-06-16', mode: 'DRY_RUN' }); console.log(JSON.stringify(plan, null, 2));"
```

Generate a DRY_RUN plan for one campaign:

```powershell
node --input-type=module -e "import { find_first_order_creatives } from './src/index.js'; const plan = await find_first_order_creatives({ advertiser_id: 'ADVERTISER_ID', campaign_id: 'CAMPAIGN_ID', date: '2026-06-16', mode: 'DRY_RUN' }); console.log(JSON.stringify(plan, null, 2));"
```

Generate a LIVE execution plan:

```powershell
node --input-type=module -e "import { execute_first_order_boost } from './src/index.js'; const plan = await execute_first_order_boost({ advertiser_id: 'ADVERTISER_ID', campaign_id: 'CAMPAIGN_ID', date: '2026-06-16', mode: 'LIVE', allow_live: true, max_boosts_per_run: 3, boost_budget_ratio: 0.2, max_boost_budget_ratio: 0.2 }); console.log(JSON.stringify(plan, null, 2));"
```

Generate the LIVE plan immediately before creating sessions. The generated `schedule_end_time` uses the current UTC date at `23:59:59`; do not reuse stale LIVE plans.

If `campaign_id` is unknown, omit it entirely. Do not pass `""` and do not pass placeholder text such as `"<CAMPAIGN_ID>"`.

## JavaScript Integration

```js
import { find_first_order_creatives, execute_first_order_boost } from "./src/index.js";

const plan = await find_first_order_creatives({
  advertiser_id: "ADVERTISER_ID",
  date: "2026-06-16",
  mode: "DRY_RUN"
});

console.log(JSON.stringify(plan, null, 2));

const livePlan = await execute_first_order_boost({
  advertiser_id: "ADVERTISER_ID",
  campaign_id: "CAMPAIGN_ID",
  date: "2026-06-16",
  mode: "LIVE",
  allow_live: true
});

console.log(JSON.stringify(livePlan, null, 2));
```

## How To Execute the Returned Plan

The output contains `tool_call_sequence`. The host agent must call each `tool_name` through the OAuth-connected TikTok Remote MCP connector.

For DRY_RUN, execute the read-only sequence:

1. Discover or load Product GMV Max campaigns.
2. Call `campaign_gmv_max_info_get`.
3. Call `gmv_max_identity_get`.
4. Call `gmv_max_video_get` and treat this eligible video pool as the source of boostable videos.
5. Call paginated `gmv_max_report_get` for the previous lookback range.
6. Call paginated `gmv_max_report_get` for the query date.
7. Intersect report rows with the eligible video pool.
8. Return candidates only. Do not call `campaign_gmv_max_session_create`.

For LIVE, execute the DRY_RUN logic first, then:

1. Call `campaign_gmv_max_session_list_get` to check active Creative Boost and Max Delivery conflicts.
2. Call `campaign_gmv_max_session_create` only for verified eligible first-order videos.
3. Call `campaign_gmv_max_session_get` and verify the created session by readback.
4. Return `session_id` and verification result.

## First-Order Rule

A video is first-order only when:

```text
orders on the query date >= min_orders
and
orders during the previous first_order_lookback_days reporting dates = 0
and
the same item exists in the gmv_max_video_get eligible video pool
```

The default lookback is 7 reporting dates. Reporting dates use the ad account timezone.

## Budget and Duration Rules

- Default boost budget ratio is `0.2`, or 20% of the source campaign budget.
- Default max boost budget ratio is also `0.2`.
- The executing agent must not exceed the max budget ratio.
- The LIVE plan schedules Creative Boost to end at `23:59:59` UTC on the current UTC date when the plan is generated.
- Generate LIVE plans immediately before calling `campaign_gmv_max_session_create`; do not reuse a stale LIVE plan.

## Safety Rules

- Default to DRY_RUN.
- LIVE requires explicit user approval.
- LIVE requires `mode: "LIVE"` and `allow_live: true`.
- Only process TikTok Product GMV Max campaigns.
- Do not select boost targets directly from report rows.
- Do not pass identity fields into `campaign_gmv_max_session_create`.
- Do not modify campaign budget.
- Do not modify ROI target.
- Verify every created session with readback.

## Troubleshooting

`Error [ERR_MODULE_NOT_FOUND]: Cannot find package 'zod'`

Run `npm install` in this package directory.

The local command prints a plan, not candidates or created sessions.

This is expected. The OAuth-connected agent platform must execute the returned TikTok MCP tool sequence.

No campaign ID is available.

Omit `campaign_id`. The plan will start with `gmv_max_campaign_get` to discover active Product GMV Max campaigns.

`campaign_id` is an empty string.

Remove the field. Empty strings do not pass validation.

## Package Contents

- `SKILL.md`: agent-facing skill instructions.
- `schema/tools_schema.json`: supported tool schemas.
- `src/`: local planner implementation.
- `scripts/validate-package.js`: package validation helper.
- `INSTRUCTIONS.md`, `MCP_SETUP.md`, and `EXAMPLE.md`: supporting material for agent packaging and review.
